package com.example.location_tracking_app_iitg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
